#include <stdio.h>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>
#include <cstring>
#include <time.h>
#include <iterator>
#include <math.h>
#include <vector>
#include <map>
#include <set>

#include "CMSketch.h"
#include "CuckooCounter.h"
#include "BubbleSketch.h"
#include "spacesaving.h"
#include "WavingSketch.h"
#include "DASketch.h"
#include "StableSketch.hpp"

using namespace std;

std::vector<std::string> func_names;
std::vector<sketch::BaseSketch*> func;

char * filename_stream = "../../data/";
char tmp[105];
string s[32000005];


char insert[20000000 + 1000000 / 5][105];
char query[20000000 + 1000000 / 5][105];

map <string ,int> C;
map <string ,int> HeavyHitter;
std::map<std::string, double> insert_throughput;
std::map<std::string, int> AAE;
std::map<std::string, double> ARE;
std::map<std::string, int> _tp;
std::map<std::string, int> _fp;


unordered_map<string, int> unmp;

#define testcycles 2
#define hh 0.00006
#define hc 0.0005

int main(int argc, char** argv)
{
    double memory = 0.1;
    if(argc >= 2)
    {
        filename_stream = argv[1];
    }
    if (argc >= 3)
    {
    	memory = stod(argv[2]);
    }
    

    unmp.clear();
    int val;
    int memory_ = memory;//KB
    int word_size = 64;

    printf("\n******************************************************************************\n");
    printf("Evaluation starts!\n\n");

    sketch::bubblesketch::BubbleSketch *bsketch;

    char _temp[200], temp2[200];
    int t = 0;

    
    char dataset[80]={'\0'};
    strcpy(dataset, filename_stream);
    cout<<"dataset: "<<dataset<<endl<<endl;

    int package_num = 0;
    FILE *file_stream = fopen(filename_stream, "rb");

    ifstream fin(dataset, ios::in|ios::binary);
    if(!fin) {printf("Dataset not exists!\n");return -1;}

    for (int i = 1; i <= MAX_INSERT_PACKAGE; i++)
    {
        if (fin.eof()) {
            break;
        }
        memset(tmp, 0, sizeof(tmp));
        package_num ++;
        fin.read(tmp, READ_KEY_LEN);
        tmp[KEY_LEN]='\0';
        s[i] = string(tmp, KEY_LEN);
        unmp[s[i]]++;
    }
    fin.close();

//    while (package_num < MAX_INSERT_PACKAGE && fin.read(tmp, READ_KEY_LEN))
//    {
//
//        package_num++;
//
//        s[package_num] = string(tmp, KEY_LEN);
//        unmp[s[package_num]]++;
//    }
//
//    fin.close();

    string flowId = "";
    int freq = 0;
    int heavyhitter_real_num = 0;
    int threshold = package_num * hh;

    printf("memory = %dKB\n", memory_);
    printf("dataset name: %s\n", filename_stream);
    printf("total stream size = %d\n", package_num);
    printf("distinct item number = %d\n", unmp.size());
    
    int max_freq = 0;
    unordered_map<string, int>::iterator it = unmp.begin();

    for(int i = 0; i < unmp.size(); i++, it++)
    {
        strcpy(query[i], it->first.c_str());

        int temp2 = it->second;
        max_freq = max_freq > temp2 ? max_freq : temp2;

        flowId = it->first;
        freq = it->second;
        if(freq < threshold){
            continue;
        }
        HeavyHitter[flowId] = freq;
        heavyhitter_real_num ++;
    }
    printf("max_freq = %d\n", max_freq);
    printf("Heavy Hitter threshold = %d\n",threshold);
    printf("Heavy Hitter numbers = %d\n", heavyhitter_real_num);

    printf("*************throughput(insert)************\n");


/********************************insert*********************************/

    timespec time1, time2;
    long long resns;

    // preparing BubbleSketch
    int stable_depth = 4;
    int bucket_size_in_bytes = sizeof(int) * 2 + KEY_LEN;
    int row= (long long)memory * 1024 / (bucket_size_in_bytes * stable_depth);

    int stable_width = row;
    func.push_back(new StableSketch(stable_depth, stable_width));

    // //preparing WavingSketch
    int WS_M = 0;
    long long bucket_size_in_bits = 32 + (long long)WS_d * (KEY_LEN * 8 + 32 + 32);
    for (WS_M = 0; bucket_size_in_bits * WS_M <= (long long)memory_ * 1024 * 8; WS_M++);
    --WS_M;
    if (WS_M <= 0) {
        std::cout << "save-all-potentiality is overflow , waving sketch can not be create" << std::endl;
    } else {
        func.push_back(new wavingsketch(WS_M, 0));
    }

    // preparing cuckoocounter
    int cc_M;

    for (cc_M = 0; (64 *CC_d * 5 + 320 + KEY_LEN * 8) * cc_M <= memory_ * 1024 * 8; cc_M++) {}
    if (cc_M % 2 == 0) {
        cc_M--;
    }
    if (cc_M <= 0) {
        std::cout << "min-heap is overflow (k is " << cc_M << "), cuckoo counter can not be create" << std::endl;
    } else {
        func.push_back(new cuckoocounter(cc_M * 5, cc_M, 3, 0.01));
    }

    // preparing CM Sketch
    int CM_M = 0;
    for (CM_M=1; (32*CM_d * 5 + 320 + KEY_LEN * 8 ) * CM_M <= memory_ * 1024 * 8; CM_M++);
    --CM_M;
    if (CM_M <= 0) {
        std::cout << "min-heap is overflow (k is " << CM_M << "), CM sketch can not be create" << std::endl;
    } else {
        func.push_back(new cmsketch(CM_M * 5 , CM_M));
    }

    //preparing spacesaving
    int ss_M;
    for (ss_M=1; (320+KEY_LEN*8)*ss_M<=memory_*1024*8; ss_M++);
    func.push_back(new spacesaving(ss_M, 0));

    // //preparing Double-Anonymous Sketch
    int DA_M;
    for (DA_M=1; (64 + KEY_LEN * 8)*DA_M*TOP_d+32*DA_M*CMM_d<=memory_*1024*8; DA_M++);
    if (DA_M%2==0) {
        DA_M--;
    }
    func.push_back(new dasketch(DA_M, 0));

        // BubbleSketch
    int bucket_num = memory_ * 1024 * 8 / (96 + KEY_LEN * 8) ;
    func.push_back(new sketch::bubblesketch::BubbleSketch(10, bucket_num, memory_));

    // prepare clear
    for (auto &iter : func) {
        func_names.push_back(iter->get_name());
        iter->clear();
    }

    for (auto &sketch_func : func) {
        clock_gettime(CLOCK_MONOTONIC, &time1);
        for (int i = 1; i <= package_num; i++) {
            sketch_func->Insert(s[i]);
        }
        clock_gettime(CLOCK_MONOTONIC, &time2);
        resns = (long long)(time2.tv_sec - time1.tv_sec) * 1000000000LL + (time2.tv_nsec - time1.tv_nsec);
        double throughput = (double)1000.0 * package_num / resns;
        printf("throughput of %s (insert): %.6lf Mips\n", sketch_func->get_name().c_str(), throughput);
        insert_throughput[sketch_func->get_name()] = throughput;
    }

    for (auto &sketch_func : func) {
        sketch_func->work();
        resns = (long long)(time2.tv_sec - time1.tv_sec) * 1000000000LL + (time2.tv_nsec - time1.tv_nsec);
        double throughput = (double)1000.0 * package_num / resns;
    }


/********************************************************************************************/
    //avoid the over-optimize of the compiler! 
    double sum = 0;

    if(sum == (1 << 30))
        return 0;

    printf("\n*************** Heavy hitter detection: ****************\n\n");
    
    printf("%08s  %08s %08s  %08s  %08s %08s\n", 
        "name", 
        "aae", 
        "are", 
        "precision", 
        "recall_bs", 
        "f1Score"
    );

    double are_bs = 0.0;
    double aae_bs = 0.0;
    int tp_bs, fp_bs, fn_bs, tn_bs = 0;

    for (auto &sketch_func : func) {
        std::set<std::string> keys;
        std::string str;
        int num;
        int heavyhitter_iter = heavyhitter_real_num + 500;
        int indexNum = bucket_num;
        if(sketch_func->get_name() == "SS"){
            indexNum = min(ss_M, heavyhitter_iter);
        }
        if(sketch_func->get_name() == "CC"){
            indexNum = min(cc_M, heavyhitter_iter);

        }
        if(sketch_func->get_name() == "CM"){
            indexNum = min(CM_M, heavyhitter_iter);
        }
        if(sketch_func->get_name() == "WS"){
            indexNum = min(WS_M, heavyhitter_iter);
        }
        if(sketch_func->get_name() == "BS"){
            indexNum = bucket_num;
        }
        for (int i = 0; i < indexNum; i++) {

            auto [str, old_num] = sketch_func->Query(i); // 获取候选字符串和它的旧频率
            if (str.empty()) continue;

            int num = 0; // 新的、准确的估计值
            // 对 CM Sketch 进行特殊处理，其他sketch不需要
            if (sketch_func->get_name() == "CM") {
                cmsketch* cm_ptr = dynamic_cast<cmsketch*>(sketch_func);
                if (cm_ptr) {
                    num = cm_ptr->get_estimate(str);
                }
            } else {
                num = old_num;
            }

            if(num < threshold){
                continue;
            }

            if (keys.count(str)) {
                continue;
            }

            
            /*not find */
            if(HeavyHitter.find(str) == HeavyHitter.end()){
                _fp[sketch_func->get_name()]++;
                continue;
            }

            keys.insert(str);
            if (HeavyHitter[str]) {
                _tp[sketch_func->get_name()]++;
                AAE[sketch_func->get_name()] += abs(unmp[str] - num);
                ARE[sketch_func->get_name()] += abs(unmp[str] - num) / (double)unmp[str];
            }
        }


        // result 
        tp_bs =  _tp[sketch_func->get_name()] ;
        fp_bs =  _fp[sketch_func->get_name()] ;
        are_bs =  ARE[sketch_func->get_name()] / (double)tp_bs;
        aae_bs =  AAE[sketch_func->get_name()] / (double)tp_bs;

        double recall_bs = tp_bs / (heavyhitter_real_num + 0.0);
        double precision_bs = tp_bs / (tp_bs + fp_bs + 0.0);
        double f1score = 2 * precision_bs * recall_bs / (precision_bs + recall_bs);

        printf("%s, %lf, %lf, %lf, %lf, %lf\n", 
            sketch_func->get_name().c_str(), 
            aae_bs, 
            are_bs, 
            precision_bs, 
            recall_bs, 
            f1score
        );

        ofstream outFile(R"(HeavyHiiter.csv)",std::ios::app);
        outFile << filename_stream <<"," 
                << sketch_func->get_name() << "," 
                << memory_ << "," 
                << aae_bs << "," 
                << are_bs << "," 
                << precision_bs << "," 
                << recall_bs << "," 
                << f1score << "," 
                <<  insert_throughput[sketch_func->get_name()] <<"\n";
        outFile.close();
    }
    printf("******************************************************************************\n");
    printf("Evaluation Ends!\n\n");

    return 0;
	
}
