#ifndef StableSketch_H
#define StableSketch_H
#include <vector>
#include <unordered_set>
#include <utility>
#include <cstring>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "datatypes.hpp"
extern "C"
{
#include "hash.h"
#include "util.h"
}
#include <string>
#include <vector>
#include <algorithm>
#include <utility>
#include <iostream>
#include <cmath>
#include <cstring>

#include "BaseSketch.h"

struct StableNode {
    std::string key;
    int count;

    static bool cmp(const StableNode& a, const StableNode& b) {
        return a.count > b.count;
    }
};


class StableSketch : public sketch::BaseSketch {
private:
    struct SBucket {
        std::string key;
        int count;
        int stablecount;
    };

    struct StableCore {
        int depth;
        int width;
        long long sum;
        SBucket** counts;
        unsigned long *hash, *scale, *hardner;
    };

    StableCore stable_;
    std::vector<StableNode> sorted_results_; // Used to store the sorted results of the work() function

    uint64_t get_hash(const std::string& str, int i) const {
        return MurmurHash64A(str.c_str(), str.length(), stable_.hardner[i]);
    }

public:

    StableSketch(int depth, int width) {
        stable_.depth = depth;
        stable_.width = width;
        stable_.sum = 0;

        stable_.counts = new SBucket*[depth * width];
        for (int i = 0; i < depth * width; i++) {
            stable_.counts[i] = new SBucket();
            stable_.counts[i]->key = "";
            stable_.counts[i]->count = 0;
            stable_.counts[i]->stablecount = 0;
        }

        stable_.hash = new unsigned long[depth];
        stable_.scale = new unsigned long[depth];
        stable_.hardner = new unsigned long[depth];
        char name[] = "Stable-Sketch";
        unsigned long seed = AwareHash((unsigned char*)name, strlen(name), 13091204281, 228204732751, 6620830889);
        for (int i = 0; i < depth; i++) {
            stable_.hash[i] = GenHashSeed(seed++);
            stable_.scale[i] = GenHashSeed(seed++);
            stable_.hardner[i] = GenHashSeed(seed++);
        }
    }

    ~StableSketch() override {
        for (int i = 0; i < stable_.depth * stable_.width; i++) {
            delete stable_.counts[i];
        }
        delete[] stable_.counts;
        delete[] stable_.hash;
        delete[] stable_.scale;
        delete[] stable_.hardner;
    }

    void Insert(const std::string &str) override {
        stable_.sum += 1;

        std::vector<int> indices(stable_.depth);

        // --- Phase 1: Find a match ---
        for (int i = 0; i < stable_.depth; ++i) {
            indices[i] = i * stable_.width + (get_hash(str, i) % stable_.width);
            SBucket* bucket = stable_.counts[indices[i]];

            if (bucket->key == str) {
                bucket->count++;
                bucket->stablecount++;
                return; // Found a match, update and return
            }
        }

        // --- Phase 2: Find an empty bucket ---
        for (int idx : indices) {
            SBucket* bucket = stable_.counts[idx];
            if (bucket->key.empty() && bucket->count == 0) {
                bucket->key = str;
                bucket->count = 1;
                bucket->stablecount = 1; // Initialize stablecount for the new item
                return; // Insert into an empty bucket and return
            }
        }

        // --- Phase 3: Probabilistic replacement ---
        // If no match or empty bucket is found, find the one with the minimum count among candidate buckets
        long min_count = 2147483647;
        int loc = -1;
        for (int idx : indices) {
            if (stable_.counts[idx]->count < min_count) {
                min_count = stable_.counts[idx]->count;
                loc = idx;
            }
        }

        if (loc != -1) {
            SBucket* bucket_to_replace = stable_.counts[loc];

            // Replacement probability is 1 / (count * stablecount + 1)
            // The original implementation was a bit obscure, so a clearer equivalent logic is used here
            long product = (long)bucket_to_replace->count * bucket_to_replace->stablecount;
            if (product < 0) product = 0;

            if ((rand() % (product + 1)) == 0) {
                bucket_to_replace->count--;
                if (bucket_to_replace->count <= 0) {
                    // The old item is completely evicted, replace it with the new item
                    bucket_to_replace->key = str;
                    bucket_to_replace->count = 1;
                    // Penalize the stability count of this bucket
                    bucket_to_replace->stablecount--;
                    if (bucket_to_replace->stablecount < 0) {
                        bucket_to_replace->stablecount = 0;
                    }
                }
            }
        }
    }

    void work() override {
        sorted_results_.clear();
        for (int i = 0; i < stable_.depth * stable_.width; ++i) {
            if (!stable_.counts[i]->key.empty() && stable_.counts[i]->count > 0) {
                sorted_results_.push_back({stable_.counts[i]->key, stable_.counts[i]->count});
            }
        }
        // Sort in descending order of count
        std::sort(sorted_results_.begin(), sorted_results_.end(), StableNode::cmp);
    }

    std::pair<std::string, int> Query(int k) override {
        if (k >= 0 && k < sorted_results_.size()) {
            return std::make_pair(sorted_results_[k].key, sorted_results_[k].count);
        }
        // If k is out of bounds, return an empty result
        return std::make_pair("", 0);
    }

    void clear() override {
        stable_.sum = 0;
        for (int i = 0; i < stable_.depth * stable_.width; i++) {
            stable_.counts[i]->key = "";
            stable_.counts[i]->count = 0;
            stable_.counts[i]->stablecount = 0;
        }
        sorted_results_.clear();
    }

    std::string get_name() override {
        return "Stable-Sketch";
    }
};

#endif // STABLE_SKETCH_HPP