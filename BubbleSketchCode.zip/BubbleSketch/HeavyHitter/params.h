#ifndef _PARAMS_H
#define _PARAMS_H

//#define MAX_INSERT_PACKAGE 10000000 //campus
//#define MAX_INSERT_PACKAGE 2400000//caida
//#define MAX_INSERT_PACKAGE 2000000 //mawi
#define MAX_INSERT_PACKAGE 16000000 //zipf

#define MAX_HASH_NUM 20

#define FILTER_SIZE 32

#define COUNTER_SIZE 16

#define LOW_HASH_NUM 4

#define MAX_MEM 68000000

#define N 34000000


#define KEY_LEN 8
//#define READ_KEY_LEN 13 //mawi caida campus
#define READ_KEY_LEN 8 //  zipf


#define MAX_INSERT 30000000
#define N MAX_INSERT  // maximum flow
#define M MAX_INSERT  // maximum size of stream-summary
#define MAX_MEM MAX_INSERT // maximum memory size
#define HK_d 2 // maximum memory size

typedef long long lint;
typedef unsigned int uint;

#endif //_PARAMS_H
