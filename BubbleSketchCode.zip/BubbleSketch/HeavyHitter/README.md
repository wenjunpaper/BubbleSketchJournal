#  Heavy Hitter Detection

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make 
$ ./HeavyHitter ./XX.data (Memory)
```
**optional** arguments:

`XX.data` is a dataset, Memory is the memory usage (unit is MB).

## Output format

Our program will print the Throughput of insertion, AAE, ARE and Precision of algorithms on the screen.
