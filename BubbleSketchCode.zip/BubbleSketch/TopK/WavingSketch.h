#ifndef _wavingsketch_H
#define _wavingsketch_H
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <string>
#include <cstring>
#include "BaseSketch.h"
#include "BOBHASH64.h"
#include "params.h"
#define WS_d 4 // Width of the heavy part of Waving Sketch
#define rep(i,a,n) for(int i=a;i<=n;i++)
using namespace std;
class wavingsketch : public sketch::BaseSketch {
private:
    struct item { string ID;int freq, flag; }; // Element in the lower Waving Sketch
    struct bucket { int count; item heavy[WS_d]; }; // Bucket in the lower Waving Sketch
    bucket WS[MAX_MEM+10]; // The lower Waving Sketch
    BOBHash64 * bobhash; // Hash function object
    int K, M2; // Top-k parameter, number of buckets
public:
    wavingsketch(int M2, int K): K(K), M2(M2) {
        bobhash = new BOBHash64(1005);
    }
    void clear() {
        memset(WS, 0, sizeof(WS));
    }
    unsigned long long Hash(string ST)
    {
        return (bobhash->run(ST.c_str(), ST.size()));
    }

    void Insert(const string &x) {
        int hash = Hash(x) % M2;
        int sign = (Hash(x) & 1) ? 1 : -1;
        bool found = false;
        rep(i, 0, WS_d - 1) {
            if (WS[hash].heavy[i].ID == x) {
                found = true;
                WS[hash].heavy[i].freq++;
                if (!WS[hash].heavy[i].flag) WS[hash].count += sign;

            }
        }

        if (!found) {
            bool empty = false;
            rep(i, 0, WS_d - 1) {
                if (WS[hash].heavy[i].ID == "") {
                    empty = true;
                    WS[hash].heavy[i].ID = x;
                    WS[hash].heavy[i].freq = 1;
                    WS[hash].heavy[i].flag = true;
                    break;
                }
            }

            if (!empty) {
                // Step 1: First, update the Waving Counter
                WS[hash].count += sign;

                // Step 2: Calculate the unbiased frequency estimate for the new element
                // This value is calculated based on the updated counter.
                int estimated_freq = WS[hash].count * sign;

                // Step 3: Find the element with the lowest frequency in the Heavy Part
                int min_freq = 0x7fffffff, min_pos = -1;
                rep(i, 0, WS_d - 1) {
                    if (WS[hash].heavy[i].freq < min_freq) {
                        min_freq = WS[hash].heavy[i].freq;
                        min_pos = i;
                    }
                }

                // Step 4: Use the correct condition to determine whether to replace
                if (estimated_freq > min_freq) {
                    // Step 5: Safely save the complete evicted item before overwriting
                    item evicted_item = WS[hash].heavy[min_pos];

                    // Step 6: Perform the replacement, overwriting the old position with the new element's information
                    WS[hash].heavy[min_pos].ID = x;
                    WS[hash].heavy[min_pos].freq = estimated_freq;
                    WS[hash].heavy[min_pos].flag = false;

                    // Step 7: If the evicted item is exact (error-free), perform counter compensation
                    if (evicted_item.flag) {
                        // Here we need to recompute the sign for the evicted item, as we only stored its ID
                        int evicted_sign = (Hash(evicted_item.ID) & 1) ? 1 : -1;
                        WS[hash].count += evicted_item.freq * evicted_sign;
                    }
                }
            }
        }


    }

    struct Node { string x; int y; } q[MAX_MEM + 10];
    static int cmp(Node i, Node j) { return i.y > j.y; }

    void work()
    {
        int CNT = 0;
        rep(i,0,M2-1){
            rep(j,0,WS_d-1){
                if(WS[i].heavy[j].ID!=""){
                    q[CNT].x = WS[i].heavy[j].ID;
                    q[CNT].y = WS[i].heavy[j].freq;
                    CNT++;
                }
            }
        }
        sort(q, q + CNT, cmp);
    }

    pair<string, int> Query(int k)
    {
        return make_pair(q[k].x, q[k].y);
    }
    std::string get_name() {
        return "WS";
    }
};
#endif