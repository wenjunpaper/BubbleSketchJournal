#Top-k Detection

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make
$ ./TopK (-d dataset -m memory -k k)
```

**optional** arguments:

- -d: set the path of dataset to run
- -m: set the memory size (KB), default memory is 400KB
- -k: set the number of top flows, default **k** is 1000

## Output format

Our program will print the Throughput of insertion, AAE, ARE and Precision of algorithms on the screen.
