#ifndef _cmsketch_H
#define _cmsketch_H
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <string>
#include <cstring>
#include "BaseSketch.h"
#include "BOBHASH32.h"
#include "params.h"
#include "ssummary.h"
#include "BOBHASH64.h"
#define CM_d 4
#define rep(i,a,n) for(int i=a;i<=n;i++)
using namespace std;
class cmsketch : public sketch::BaseSketch{
private:
    ssummary *ss;
    struct node { int C; } HK[CM_d][MAX_MEM+10];
    BOBHash64 * bobhash;
    int K, M2, d;
public:
    cmsketch(int M2, int K) :M2(M2), K(K) { ss = new ssummary(K); ss->clear(); bobhash = new BOBHash64(1005); }
    void clear()
    {
        for (int i = 0; i < CM_d; i++)
            for (int j = 0; j <= M2 + 5; j++)
                HK[i][j].C = 0;
    }
    unsigned long long Hash(string ST)
    {
        return (bobhash->run(ST.c_str(), ST.size()));
    }
    void Insert(const string &x)
    {

        // 1. Get the current minimum estimate before updating.
        int old_minv = get_estimate(x);

        // 2. Calculate hash values.
        unsigned long long hash[CM_d];
        for (int i = 0; i < CM_d; i++)
            hash[i] = Hash(x + std::to_string(i)) % (M2 - (2 * CM_d) + 2 * i + 3);

        // 3. Conservatively increment counters: only increment those equal to old_minv.
        for (int i = 0; i < CM_d; i++)
        {
            if (HK[i][hash[i]].C == old_minv)
            {
                HK[i][hash[i]].C++;
            }
        }

        // 4. Get the new count after update, used for updating ssummary.
        //    For conservative update, the new value is old_minv + 1.
        int new_minv = old_minv + 1;



        // --- Use the updated and more accurate new_minv to update ssummary ---
        bool mon = false;
        int p = ss->find(x);
        if (p) mon = true;

        if (!mon)
        {
            if (new_minv - (ss->getmin()) > 0 || ss->tot < K)
            {
                int i = ss->getid();
                ss->add2(ss->location(x), i);
                ss->str[i] = x;
                ss->sum[i] = new_minv;
                ss->link(i, 0);
                while (ss->tot > K)
                {
                    int t = ss->Right[0];
                    int tmp = ss->head[t];
                    ss->cut(ss->head[t]);
                    ss->recycling(tmp);
                }
            }
        }
        else
        {
            // Note: new_minv is also used here.
            if (new_minv > ss->sum[p])
            {
                int tmp = ss->Left[ss->sum[p]];
                ss->cut(p);
                if (ss->head[ss->sum[p]]) tmp = ss->sum[p];
                ss->sum[p] = new_minv; // Use new_minv
                ss->link(p, tmp);
            }
        }
    }
    struct Node { string x; int y; } q[MAX_MEM + 10];
    static int cmp(Node i, Node j) { return i.y > j.y; }
    void work() {
        int CNT = 0;
        // Extract all candidate flows and their historical counts from ssummary.
        for (int i = N; i; i = ss->Left[i])
            for (int j = ss->head[i]; j; j = ss->Next[j]) {
                q[CNT].x = ss->str[j];
                // Call get_estimate() to get the most accurate current frequency estimate for this flow.
                q[CNT].y = get_estimate(ss->str[j]);
                CNT++;
                sort(q, q + CNT, cmp);
            }
    }
    pair<string, int> Query(int k)
    {
        return make_pair(q[k].x, q[k].y);
    }
    std::string get_name() {
        return "CM";
    }
    int get_estimate(const string &x)
    {
        int minv = 0x7fffffff;
        unsigned long long hash[CM_d];
        for (int i = 0; i < CM_d; i++)
            hash[i] = Hash(x + std::to_string(i)) % (M2 - (2 * CM_d) + 2 * i + 3);

        for(int i = 0; i < CM_d; i++)
        {
            minv = min(minv, HK[i][hash[i]].C);
        }
        return minv;
    }
};
#endif