#ifndef _PARAMS_H
#define _PARAMS_H

//#define MAX_INSERT_PACKAGE 10000000  //campus
//#define MAX_INSERT_PACKAGE 2400000//caida
//#define MAX_INSERT_PACKAGE 2000000 //mawi
#define MAX_INSERT_PACKAGE 16000000 //zipf

#define N MAX_INSERT_PACKAGE  // maximum flow
#define M MAX_INSERT_PACKAGE  // maximum size of stream-summary
#define MAX_MEM MAX_INSERT_PACKAGE // maximum memory size
#define HK_d 2 // maximum memory size

#define KEY_LEN 8
//#define READ_KEY_LEN 13 //mawi caida campus
#define READ_KEY_LEN 8 //  zipf

#endif //_PARAMS_H
