#./Persistent -d ../../dataset/CAIDA-10-dataset/1.dat -m 4
#./Persistent -d ../../dataset/CAIDA-10-dataset/1.dat -m 8
#./Persistent -d ../../dataset/CAIDA-10-dataset/1.dat -m 16
#./Persistent -d ../../dataset/CAIDA-10-dataset/1.dat -m 32
#./Persistent -d ../../dataset/CAIDA-10-dataset/1.dat -m 64

#./Persistent -d ../../dataset/documents-export-2025-06-19/campus.dat -m 4
#./Persistent -d ../../dataset/documents-export-2025-06-19/campus.dat -m 8
#./Persistent -d ../../dataset/documents-export-2025-06-19/campus.dat -m 16
#./Persistent -d ../../dataset/documents-export-2025-06-19/campus.dat -m 32
#./Persistent -d ../../dataset/documents-export-2025-06-19/campus.dat -m 64

#./Persistent -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 4
#./Persistent -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 8
#./Persistent -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 16
#./Persistent -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 32
#./Persistent -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 64

./Persistent -d ../../dataset/zipf_0.5keyLen8.dat -m 4
./Persistent -d ../../dataset/zipf_0.5keyLen8.dat -m 8
./Persistent -d ../../dataset/zipf_0.5keyLen8.dat -m 16
./Persistent -d ../../dataset/zipf_0.5keyLen8.dat -m 32
./Persistent -d ../../dataset/zipf_0.5keyLen8.dat -m 64
#
./Persistent -d ../../dataset/zipf_1.0keyLen8.dat -m 4
./Persistent -d ../../dataset/zipf_1.0keyLen8.dat -m 8
./Persistent -d ../../dataset/zipf_1.0keyLen8.dat -m 16
./Persistent -d ../../dataset/zipf_1.0keyLen8.dat -m 32
./Persistent -d ../../dataset/zipf_1.0keyLen8.dat -m 64

./Persistent -d ../../dataset/zipf_1.5keyLen8.dat -m 4
./Persistent -d ../../dataset/zipf_1.5keyLen8.dat -m 8
./Persistent -d ../../dataset/zipf_1.5keyLen8.dat -m 16
./Persistent -d ../../dataset/zipf_1.5keyLen8.dat -m 32
./Persistent -d ../../dataset/zipf_1.5keyLen8.dat -m 64
