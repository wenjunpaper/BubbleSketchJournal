#./bench -d data/caida.dat -m 4
#./bench -d data/caida.dat -m 8
#./bench -d data/caida.dat -m 16
#./bench -d data/caida.dat -m 32
#./bench -d data/caida.dat -m 64

#./bench -d ../../dataset/CAIDA-10-dataset/2.dat -m 4
#./bench -d ../../dataset/CAIDA-10-dataset/2.dat -m 8
#./bench -d ../../dataset/CAIDA-10-dataset/2.dat -m 16
#./bench -d ../../dataset/CAIDA-10-dataset/2.dat -m 32
#./bench -d ../../dataset/CAIDA-10-dataset/2.dat -m 64

#./bench -d ../../dataset/documents-export-2025-06-19/campus.dat -m 4
#./bench -d ../../dataset/documents-export-2025-06-19/campus.dat -m 8
#./bench -d ../../dataset/documents-export-2025-06-19/campus.dat -m 16
#./bench -d ../../dataset/documents-export-2025-06-19/campus.dat -m 32
#./bench -d ../../dataset/documents-export-2025-06-19/campus.dat -m 64

#./bench -d ../../dataset/documents-export-2025-06-19/IMC.dat -m 4
#./bench -d ../../dataset/documents-export-2025-06-19/IMC.dat -m 8
#./bench -d ../../dataset/documents-export-2025-06-19/IMC.dat -m 16
#./bench -d ../../dataset/documents-export-2025-06-19/IMC.dat -m 32
#./bench -d ../../dataset/documents-export-2025-06-19/IMC.dat -m 64

#./bench -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 4
#./bench -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 8
#./bench -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 16
#./bench -d ../../dataset/documents-export-2025-06-19/MAWI2000000.dat -m 32
#./bench -d /root/dataset/MAWI2000000.dat -m 64

./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 4
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 8
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 16
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 32
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 64

./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 4
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 8
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 16
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 32
./bench -d /root/dataset/zipf_0.5keyLen8.dat -m 64