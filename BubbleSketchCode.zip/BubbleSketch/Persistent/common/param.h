#ifndef BENCH_PARAM_H
#define BENCH_PARAM_H


//#define INSERT_PACKET 10000000 //campus
//#define INSERT_PACKET 2400000//caida
//#define INSERT_PACKET 2000000 //mawi
#define INSERT_PACKET 16000000 //zipf



//#define KEY_LEN 13 //mawi caida campus
#define KEY_LEN 8 //  zipf



#endif //BENCH_PARAM_H
