#ifndef BITSET_H_MODIFIED
#define BITSET_H_MODIFIED

#include "bitset.h"
#include "Abstract.h"
#include "LossyStrategy.h"
#include <string>
#include <algorithm>
#include <functional>
#include <iostream>
#include <limits.h>
#include <stdint.h>
#include <vector>
#include "param.h"

const int MAX_ROW = 2;
const int MAX_ENTRY = 5;

// Forward declaration of template classes
template<typename DATA_TYPE>
class Entry;

template<typename DATA_TYPE>
class Bucket;

// --- Entry Class (Templated) ---
template<typename DATA_TYPE>
class Entry {
public:
    Entry() : ID(DATA_TYPE()), fingerprint(0), count(0) {}
    Entry(const DATA_TYPE &id, uint32_t fp, uint32_t cnt,uint8_t st)
            : ID(id), fingerprint(fp>>24), count(cnt){}
    uint32_t Empty();
    bool Equalfp(uint8_t fp);

    bool EqualID(const DATA_TYPE &id);
    void Insert();
    void Insert(uint32_t &fp, const DATA_TYPE &id, uint32_t cnt = 1,uint8_t st=0);
    void Lossy(std::function<void(uint32_t &)> &lossy_func);

    uint8_t get_fingerprint();

    uint32_t get_count();
    DATA_TYPE get_ID();
    void reset();
    bool operator<(const Entry<DATA_TYPE> &e) const { return count > e.count; }

private:
    DATA_TYPE ID;
    uint8_t fingerprint;
    uint32_t count;

};

// --- Bucket Class (Templated) ---
template<typename DATA_TYPE>
class Bucket {
public:
    Bucket() { entries.resize(MAX_ENTRY); }
    void Clear();
    bool Empty(int index);
    bool Full(int index);
    void Insert(int index);
    void Insert(int index, const Entry<DATA_TYPE> &entry);
    void Insert(int index, uint32_t fp,
                const DATA_TYPE &id);
    void Remove(int index);
    void Lossy(int index, std::function<void(uint32_t &)>
    &lossy_func);
    void BucketSort(int index);
    bool Equal(int index, uint32_t fp,const DATA_TYPE &id);
    uint8_t get_fp(int index);
    DATA_TYPE get_ID(int index);
    Entry<DATA_TYPE> get_entry(int index);
    int get_col_index();
    int get_entry_count(int index);
    void down_stairs(int index);
    void reset(int index);
    std::vector<Entry<DATA_TYPE>> entries;

private:
    int col_index;
};

template<typename DATA_TYPE, typename COUNT_TYPE>
class BubbleSketch : public Abstract<DATA_TYPE, COUNT_TYPE> {
public:
    BubbleSketch(int threshold1,int MEM);
    ~BubbleSketch();
    void clear();
    void Insert(const DATA_TYPE item, const COUNT_TYPE window);
    COUNT_TYPE Query(const DATA_TYPE item);
    void NewWindow(const COUNT_TYPE window);
    void work();
    double Buckets_Used();
    std::string getName();
    void reset();

private:
    bool kickout(int kick_num, uint64_t &hash_value, Bucket<DATA_TYPE> &cur_bucket,
                 int entry_index, int array_index);
    int _bucket_num;
    int _threshold1;
    std::vector<std::vector<Bucket<DATA_TYPE>>> _buckets;
    Lossy::BaseStrategy *_lossy;
    std::function<void(uint32_t &)> _lossy_func;
    std::vector<Entry<DATA_TYPE>> _ret;
    BitSet * _bucketBitsets;

    int cur_count;
};

const int MAX_KICK_OUT = 1;


// --- Entry Method Implementations ---

template<typename DATA_TYPE>
uint32_t Entry<DATA_TYPE>::Empty() { return count == 0; }

template<typename DATA_TYPE>
bool Entry<DATA_TYPE>::Equalfp(uint8_t fp) { return fp == fingerprint; }

template<typename DATA_TYPE>
bool Entry<DATA_TYPE>::EqualID(const DATA_TYPE &id) { return this->ID == id; }

template<typename DATA_TYPE>
void Entry<DATA_TYPE>::Insert() { ++count;}

template<typename DATA_TYPE>
void Entry<DATA_TYPE>::Insert(uint32_t &fp, const DATA_TYPE &id, uint32_t cnt,uint8_t st) {
    fingerprint = fp >> 24;
    this->ID = id;
    this->count = cnt;
}

template<typename DATA_TYPE>
void Entry<DATA_TYPE>::Lossy(std::function<void(uint32_t &)> &lossy_func) {
    lossy_func(count);
}

template<typename DATA_TYPE>
uint8_t Entry<DATA_TYPE>::get_fingerprint() { return fingerprint; }

template<typename DATA_TYPE>
uint32_t Entry<DATA_TYPE>::get_count() { return count; }

template<typename DATA_TYPE>
DATA_TYPE Entry<DATA_TYPE>::get_ID() { return ID; }

template<typename DATA_TYPE>
void Entry<DATA_TYPE>::reset() {
    fingerprint = 0;
    this->ID = DATA_TYPE();
    this->count = 0;
}

// --- Bucket Method Implementations ---

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::Clear() {
    entries.clear();
    entries.resize(MAX_ENTRY);
}

template<typename DATA_TYPE>
bool Bucket<DATA_TYPE>::Empty(int index) { return entries[index].Empty(); }

template<typename DATA_TYPE>
DATA_TYPE Bucket<DATA_TYPE>::get_ID(int index) { return entries[index].get_ID(); }

template<typename DATA_TYPE>
bool Bucket<DATA_TYPE>::Full(int index) {
    switch (index) {
        case 0:
            return entries[index].get_count() == 0xffff;
        case 1:
            return entries[index].get_count() == 0xffff;
        case 2:
            return entries[index].get_count() == 0xffff;
        case 3:
        case 4:
            return entries[index].get_count() == 0xff;
    }
    return false;
}

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::Insert(int index) {
    entries[index].Insert();
}

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::Insert(int index, const Entry<DATA_TYPE> &entry) { entries[index] = entry; }

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::Insert(int index, uint32_t fp, const DATA_TYPE &id) {
    entries[index].Insert(fp, id);
}

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::Remove(int index) {
    while (index + 1 < MAX_ENTRY) {
        entries[index] = std::move(entries[index + 1]);
        index++;
    }
    entries[MAX_ENTRY - 1].reset();
}

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::Lossy(int index, std::function<void(uint32_t &)> &lossy_func) {
    entries[index].Lossy(lossy_func);
}

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::BucketSort(int index) {
    while (index > 0 &&
           entries[index].get_count() > entries[index - 1].get_count()) {
        std::swap(entries[index], entries[index - 1]);
        --index;
    }
}

template<typename DATA_TYPE>
bool Bucket<DATA_TYPE>::Equal(int index, uint32_t fp, const DATA_TYPE &id) {
    if (index == 0) {
        return entries[index].EqualID(id);
    } else {
        return entries[index].Equalfp(fp >> 24);
    }
}

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::reset(int index){
    entries[index].reset();
}

template<typename DATA_TYPE>
uint8_t Bucket<DATA_TYPE>::get_fp(int index) {
    return entries[index].get_fingerprint();
}

template<typename DATA_TYPE>
Entry<DATA_TYPE> Bucket<DATA_TYPE>::get_entry(int index) { return entries[index]; }

template<typename DATA_TYPE>
int Bucket<DATA_TYPE>::get_col_index() { return col_index; }

template<typename DATA_TYPE>
int Bucket<DATA_TYPE>::get_entry_count(int index) { return entries[index].get_count(); }

template<typename DATA_TYPE>
void Bucket<DATA_TYPE>::down_stairs(int index) {
    int cur_index = MAX_ENTRY - 1;
    while (cur_index > index) {
        entries[cur_index] = std::move(entries[cur_index - 1]);
        --cur_index;
    }
}

// --- BubbleSketch Method Implementations ---

template<typename DATA_TYPE, typename COUNT_TYPE>
BubbleSketch<DATA_TYPE, COUNT_TYPE>::BubbleSketch(int threshold1, int MEM) {
//    const int BUCKETSIZE = 128 + 5;
    const int BUCKETSIZE = 96 + 5 * 8 * BITSIZE + sizeof(DATA_TYPE) * 8;
    _bucket_num = 0;
    for (; _bucket_num * BUCKETSIZE * MAX_ROW <= MEM * 1024 * 8; ++_bucket_num)
        ;
    --_bucket_num;
    _buckets.resize(MAX_ROW, std::vector<Bucket<DATA_TYPE>>(_bucket_num));
    _bucketBitsets = new BitSet(_bucket_num * MAX_ROW * MAX_ENTRY);

    _threshold1 = threshold1;
    _lossy_func = Lossy::MinusOneStrategy{};
}

template<typename DATA_TYPE, typename COUNT_TYPE>
BubbleSketch<DATA_TYPE, COUNT_TYPE>::~BubbleSketch() {
    delete _bucketBitsets;
}

template<typename DATA_TYPE, typename COUNT_TYPE>
void BubbleSketch<DATA_TYPE, COUNT_TYPE>::clear() {
    _buckets.clear();
    _buckets.resize(MAX_ROW, std::vector<Bucket<DATA_TYPE>>(_bucket_num));
}

template<typename DATA_TYPE, typename COUNT_TYPE>
void BubbleSketch<DATA_TYPE, COUNT_TYPE>::Insert(const DATA_TYPE item, const COUNT_TYPE window){
    uint64_t hash_key = this->hash64(item, 1005);
    uint32_t fp = hash_key >> 32;
    uint64_t hash_value[2] = {hash_key, hash_key + (fp >> 24)};

    uint64_t keys[2] = {hash_value[0] % _bucket_num,
                        hash_value[1] % _bucket_num};

    uint32_t bucketBitPos = 0;
    uint32_t w_bucketBitPos = 0;

    for (int i = 0; i < MAX_ROW; ++i) {
        bucketBitPos = 0;
        Bucket<DATA_TYPE> &bucket = _buckets[i][keys[i]];

        for (int j = 0; j < MAX_ENTRY; j++) {
            bucketBitPos = i * _bucket_num * MAX_ENTRY + keys[i] * MAX_ENTRY + j ;

            if (bucket.Equal(j, fp, item)) {
                if(_bucketBitsets->Get(bucketBitPos) == 1){
                    return;
                }
                if(bucket.Full(j)){
                    return;
                }
                bucket.Insert(j);
                _bucketBitsets->Set(bucketBitPos);

                int index = j;
                int flag_f = 0;
                int flag_s = 0;

                w_bucketBitPos = i * _bucket_num * MAX_ENTRY + keys[i] * MAX_ENTRY + index ;
                while (index > 0 &&
                       bucket.entries[index].get_count() > bucket.entries[index - 1].get_count()) {
                    std::swap(bucket.entries[index], bucket.entries[index - 1]);

                    flag_f = _bucketBitsets->Get(w_bucketBitPos);
                    flag_s = _bucketBitsets->Get(w_bucketBitPos - 1);

                    if (flag_f == 1){
                        _bucketBitsets->Set(w_bucketBitPos - 1);
                    }else{
                        _bucketBitsets->Reset(w_bucketBitPos - 1);
                    }

                    if(flag_s == 1){
                        _bucketBitsets->Set(w_bucketBitPos);
                    }else{
                        _bucketBitsets->Reset(w_bucketBitPos);
                    }

                    --index;
                    --w_bucketBitPos;
                }

                if (bucket.get_entry_count(1) > _threshold1) {
                    if (kickout(MAX_KICK_OUT, hash_value[i], bucket, 1, i)) {
                        bucket.Remove(1);
                    }
                }
                return;
            }
            if (bucket.Empty(j)) {
                bucket.Insert(j, fp, item);
                _bucketBitsets->Set(bucketBitPos);
                return;
            }
        }
    }

    Bucket<DATA_TYPE> &bucket0 = _buckets[0][keys[0]];
    Bucket<DATA_TYPE> &bucket1 = _buckets[1][keys[1]];
    if (bucket0.get_entry_count(MAX_ENTRY - 1) <
        bucket1.get_entry_count(MAX_ENTRY - 1)) {
        bucket0.Lossy(MAX_ENTRY - 1, _lossy_func);
    } else {
        bucket1.Lossy(MAX_ENTRY - 1, _lossy_func);
    }
}

template<typename DATA_TYPE, typename COUNT_TYPE>
COUNT_TYPE BubbleSketch<DATA_TYPE, COUNT_TYPE>::Query(const DATA_TYPE item) {
    uint64_t hash_key = this->hash64(item, 1005);
    uint32_t fp = hash_key >> 32;
    uint64_t hash_value[2] = {hash_key, hash_key + (fp >> 24)};
    uint64_t keys[2] = {hash_value[0] % _bucket_num,
                        hash_value[1] % _bucket_num};

    Bucket<DATA_TYPE> &bucket0 = _buckets[0][keys[0]];
    Bucket<DATA_TYPE> &bucket1 = _buckets[1][keys[1]];
    for(int i=0;i<MAX_ENTRY;i++){
        if(bucket0.Equal(i, fp,item)){
            return bucket0.get_entry_count(i);
        }
        if(bucket1.Equal(i, fp,item)){
            return bucket1.get_entry_count(i);
        }
    }
    return std::min(bucket0.get_entry_count(MAX_ENTRY-1),bucket1.get_entry_count(MAX_ENTRY-1));
}

template<typename DATA_TYPE, typename COUNT_TYPE>
void BubbleSketch<DATA_TYPE, COUNT_TYPE>::work() {
    _ret.resize(_bucket_num * MAX_ROW);
    for (int i = 0; i < MAX_ROW; i++) {
        for (int j = 0; j < _bucket_num; j++) {
            _ret[i * _bucket_num + j] = _buckets[i][j].get_entry(0);
        }
    }
    sort(_ret.begin(), _ret.end());
}

template<typename DATA_TYPE, typename COUNT_TYPE>
double BubbleSketch<DATA_TYPE, COUNT_TYPE>::Buckets_Used() {
    double m=_bucket_num* MAX_ROW;
    int n = 0;
    for (int i = 0; i < MAX_ROW; i++) {
        for (int j = 0; j < _bucket_num; j++) {
            // Note: Printing ID might require specific stream overloads for DATA_TYPE
            if (_buckets[i][j].get_entry_count(0) != 0 && _buckets[i][j].get_fp(0) != -1) n++;
        }
    }
    double rat = n / m;
    return rat;
}

template<typename DATA_TYPE, typename COUNT_TYPE>
void BubbleSketch<DATA_TYPE, COUNT_TYPE>::reset(){
    double m=_bucket_num* MAX_ROW;
    int n = 0;
    for (int i = 0; i < MAX_ROW; i++) {
        for (int j = 0; j < _bucket_num; j++) {
            for(int k=0;k<MAX_ENTRY;k++){
                _buckets[i][j].reset(k);
            }
        }
    }
}

template<typename DATA_TYPE, typename COUNT_TYPE>
void BubbleSketch<DATA_TYPE, COUNT_TYPE>::NewWindow(const COUNT_TYPE window) {
    _bucketBitsets->Clear();
}

template<typename DATA_TYPE, typename COUNT_TYPE>
std::string BubbleSketch<DATA_TYPE, COUNT_TYPE>::getName() { return "BS"; }

template<typename DATA_TYPE, typename COUNT_TYPE>
bool BubbleSketch<DATA_TYPE, COUNT_TYPE>::kickout(int kick_num, uint64_t &hash_value,
                                                  Bucket<DATA_TYPE> &cur_bucket, int entry_index,
                                                  int array_index) {
    if (kick_num == 0) {
        return false;
    }

    uint8_t fp = cur_bucket.get_fp(entry_index);
    int index = MAX_ENTRY-1;
    int flag_f = 0;
    int flag_s = 0;
    uint32_t bucketBitPos = 0;
    uint32_t w_bucketBitPos = 0;
    bucketBitPos = array_index * _bucket_num * MAX_ENTRY + (hash_value % _bucket_num) * MAX_ENTRY + entry_index ;

    uint64_t next_hash_value = hash_value;
    if (array_index == 0) {
        next_hash_value += fp;
    } else {
        next_hash_value -= fp;
    }
    Bucket<DATA_TYPE> &next_bucket =
            _buckets[1 - array_index][next_hash_value % _bucket_num];

    w_bucketBitPos = (1 - array_index) * _bucket_num * MAX_ENTRY + (next_hash_value % _bucket_num) * MAX_ENTRY + index;
    if (cur_bucket.get_entry_count(entry_index) >
        next_bucket.get_entry_count(0)) {
        next_bucket.down_stairs(0);
        next_bucket.Insert(0, cur_bucket.get_entry(entry_index));
        while (index > 0) {

            flag_f = _bucketBitsets->Get(w_bucketBitPos);
            flag_s = _bucketBitsets->Get(w_bucketBitPos - 1);

            if(flag_s == 1){
                _bucketBitsets->Set(w_bucketBitPos);
            }else{
                _bucketBitsets->Reset(w_bucketBitPos);
            }

            --index;
            --w_bucketBitPos;
        }
        flag_f = _bucketBitsets->Get(bucketBitPos);
        if (flag_f == 1){
            _bucketBitsets->Set(w_bucketBitPos);
        }else{
            _bucketBitsets->Reset(w_bucketBitPos);
        }

        return true;
    }


    if (kickout(kick_num - 1, next_hash_value, next_bucket, 0,
                1 - array_index) ) {

        next_bucket.Insert(0, cur_bucket.get_entry(entry_index));
        flag_f = _bucketBitsets->Get(bucketBitPos);
        if (flag_f == 1){
            _bucketBitsets->Set(w_bucketBitPos);
        }else{
            _bucketBitsets->Reset(w_bucketBitPos);
        }
        return true;
    }
    return false;
}

#endif //BITSET_H_MODIFIED