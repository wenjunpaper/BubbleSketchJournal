#ifndef WINDOW_SKETCH_SS_H
#define WINDOW_SKETCH_SS_H

#include "Abstract.h"
#include <limits>

template<typename DATA_TYPE,typename COUNT_TYPE>
class SS : public Abstract<DATA_TYPE, COUNT_TYPE> {
public:
    struct PCounter {
        COUNT_TYPE window;
        COUNT_TYPE count;

        PCounter(COUNT_TYPE _window = 0, COUNT_TYPE _count = 0):
                window(_window), count(_count){}
    };

    typedef std::unordered_map<DATA_TYPE, PCounter> SSMap;

    SS(double _EPSILON, size_t _max_size):
            EPSILON(_EPSILON), max_size(_max_size) {}

    ~SS(){}

    void Insert(const DATA_TYPE item, const COUNT_TYPE window){
        if(ssmap.find(item) != ssmap.end()){
            if(ssmap[item].window < window){
                ssmap[item].window = window;
                ssmap[item].count += 1;
            }
        }
        else{
            uint8_t str[sizeof(DATA_TYPE) + sizeof(COUNT_TYPE)];
            memcpy(str, &item, sizeof(DATA_TYPE));
            memcpy(str + sizeof(DATA_TYPE), &window, sizeof(COUNT_TYPE));

            if(Hash::BOBHash32(str, sizeof(DATA_TYPE) + sizeof(COUNT_TYPE), 0)
               / (double)(UINT_MAX) < EPSILON){

                // === Start of new eviction logic ===
                if (ssmap.size() >= max_size) {
                    // The table is full, an element needs to be evicted.
                    typename SSMap::iterator victim = ssmap.end();
                    COUNT_TYPE min_count = std::numeric_limits<COUNT_TYPE>::max();

                    // Iterate through the hash map to find the element with the minimum count as the victim.
                    for (auto it = ssmap.begin(); it != ssmap.end(); ++it) {
                        if (it->second.count < min_count) {
                            min_count = it->second.count;
                            victim = it;
                        }
                    }

                    // If a victim is found, evict it.
                    if (victim != ssmap.end()) {
                        ssmap.erase(victim);
                    }
                }
                // === End of eviction logic ===

                // Insert the new element (assuming the table is not full or space has been made).
                if (ssmap.size() < max_size) {
                    ssmap[item] = PCounter(window, 1);
                }
            }
        }
    }

    COUNT_TYPE Query(const DATA_TYPE item){
        if(ssmap.find(item) == ssmap.end())
            return 0;
        return ssmap[item].count + 1 / EPSILON;
    }

    std::string getName(){
        return "Small-Space";
    }

    void reset(){
        ssmap.clear();
    }

    void NewWindow(const COUNT_TYPE window){}

private:
    const double EPSILON;
    const size_t max_size;
    SSMap ssmap;
};

#endif //SS_H