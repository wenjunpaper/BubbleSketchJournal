#ifndef OO_FPI_H
#define OO_FPI_H

/*
 * On-Off sketch on finding persistent items
 * * ===================================================================================
 * MODIFICATION NOTE:
 * The Insert function has been corrected to align with the algorithm described in the
 * "On-Off Sketch" paper (PVLDB, 14(2): 128-140, 2021). The original implementation
 * had an incorrect replacement strategy. The corrected logic implements the
 * "swap-with-minimum" promotion mechanism.
 * ===================================================================================
 */

#include "bitset.h"
#include "Abstract.h"
#include <algorithm> // Required for std::swap

template<typename DATA_TYPE, typename COUNT_TYPE, uint32_t SLOT_NUM>
class OnOffSketch : public Abstract<DATA_TYPE, COUNT_TYPE> {
public:

    struct Bucket {
        DATA_TYPE items[SLOT_NUM];
        COUNT_TYPE counters[SLOT_NUM];

        inline COUNT_TYPE Query(const DATA_TYPE item){
            for(uint32_t i = 0;i < SLOT_NUM;++i){
                if(items[i] == item){
                    return counters[i];
                }
            }
            return 0;
        }
    };

    OnOffSketch(uint64_t memory) :
    // Memory calculation is correct.
            length((double)memory / (sizeof(Bucket) + sizeof(COUNT_TYPE) + (SLOT_NUM + 1) * BITSIZE))
    {
        buckets = new Bucket[length];
        sketch = new COUNT_TYPE [length];

        memset(buckets, 0, length * sizeof(Bucket));
        memset(sketch, 0, length * sizeof(COUNT_TYPE));

        bucketBitsets = new BitSet(SLOT_NUM * length);
        sketchBitsets = new BitSet(length);
    }

    ~OnOffSketch(){
        delete [] buckets;
        delete [] sketch;
        delete bucketBitsets;
        delete sketchBitsets;
    }

    std::string getName() {
        return "OO";
    }

    void Insert(const DATA_TYPE item, const COUNT_TYPE window){
        uint32_t pos = this->hash(item) % length;
        uint32_t bucketBitPos = pos * SLOT_NUM;

        // Check if the item is already in the bucket
        for(uint32_t i = 0; i < SLOT_NUM; ++i){
            if(buckets[pos].items[i] == item){
                // If found, increment its counter if the state is "On"
                // SetNGet sets the bit to 1 ("Off") and returns the old state.
                // We add 1 only if the old state was 0 ("On").
                buckets[pos].counters[i] += (!bucketBitsets->SetNGet(bucketBitPos + i));
                return;
            }
        }

        // ===================================================================================
        //                              CORRECTED LOGIC STARTS HERE
        // ===================================================================================
        // If the item is not in the bucket, treat it as a candidate.
        // This logic implements the promotion mechanism from the paper.

        // 1. Increment the anonymous sketch counter if its state is "On".
        bool sketch_was_already_off = sketchBitsets->SetNGet(pos);
        if (!sketch_was_already_off) {
            sketch[pos]++;
        }

        // 2. Find the item with the minimum counter in the bucket.
        uint32_t min_idx = 0;
        COUNT_TYPE min_val = buckets[pos].counters[0];
        for (uint32_t i = 1; i < SLOT_NUM; ++i) {
            if (buckets[pos].counters[i] < min_val) {
                min_val = buckets[pos].counters[i];
                min_idx = i;
            }
        }

        // 3. Compare the sketch counter with the bucket's minimum.
        // If the candidate's estimated persistence is higher, swap it into the bucket.
        if (sketch[pos] > min_val) {
            // Get the state of the counter being evicted before swapping.
            uint32_t evicted_counter_bit_index = bucketBitPos + min_idx;
            bool evicted_counter_was_off = bucketBitsets->Get(evicted_counter_bit_index);

            // Swap the counter values. The larger value from sketch[] moves into the bucket.
            std::swap(sketch[pos], buckets[pos].counters[min_idx]);

            // The new item takes the place of the evicted item.
            buckets[pos].items[min_idx] = item;

            // Now, swap their "On/Off" states as described in the paper.
            // a. The new item in the bucket takes the state of the sketch counter,
            //    which is now "Off" (bit=1) because it was just incremented.
            bucketBitsets->Set(evicted_counter_bit_index);

            // b. The sketch counter takes the old state of the evicted bucket counter.
            if (evicted_counter_was_off) {
                sketchBitsets->Set(pos);
            } else {
                sketchBitsets->Reset(pos);
            }
        }
        // ===================================================================================
        //                              CORRECTED LOGIC ENDS HERE
        // ===================================================================================
    }

    COUNT_TYPE Query(const DATA_TYPE item){
        return buckets[this->hash(item) % length].Query(item);
    }

    void NewWindow(const COUNT_TYPE window){
        // At the beginning of a new window, all states are reset to "On" (bits cleared to 0).
        bucketBitsets->Clear();
        sketchBitsets->Clear();
    }

    void reset(){
        bucketBitsets->Clear();
        sketchBitsets->Clear();
        memset(buckets, 0, length * sizeof(Bucket));
        memset(sketch, 0, length * sizeof(COUNT_TYPE));
    }

private:
    const uint32_t length;

    BitSet* bucketBitsets;
    Bucket* buckets;

    BitSet* sketchBitsets;
    COUNT_TYPE* sketch;
};

#endif //OO_FPI_H