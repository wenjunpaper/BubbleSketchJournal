#ifndef TIGHTSKETCH_H
#define TIGHTSKETCH_H

#include "Abstract.h"
#include <vector>
#include <cstring>
#include <limits>

template<typename DATA_TYPE, typename COUNT_TYPE>
class TightSketch : public Abstract<DATA_TYPE, COUNT_TYPE> {
private:
    struct SBucket {
        COUNT_TYPE count;
        COUNT_TYPE hotcount;
        DATA_TYPE key;
        uint8_t status;

        SBucket() : count(0), hotcount(0), key(0), status(0) {}
    };

    int depth;
    int width;
    COUNT_TYPE M_threshold;
    COUNT_TYPE sum;
    SBucket* counts;

public:
    TightSketch(int _depth, int _width, COUNT_TYPE _M_threshold = 10)
            : depth(_depth), width(_width), M_threshold(_M_threshold), sum(0) {

        counts = new SBucket[depth * width]();
    }

    ~TightSketch() {
        delete[] counts;
    }

    void Insert(const DATA_TYPE item, const COUNT_TYPE window) override {
        sum += 1;
        int loc = -1;
        COUNT_TYPE min_val = std::numeric_limits<COUNT_TYPE>::max();

        for (int i = 0; i < depth; i++) {
            unsigned long bucket_idx = this->hash(item, i) % width;
            int index = i * width + bucket_idx;
            SBucket* sbucket = &counts[index];

            // Case 1: Bucket is empty, insert directly
            if (sbucket->key == 0) {
                sbucket->key = item;
                sbucket->count = 1;
                sbucket->hotcount = 1;
                sbucket->status = 1;
                return;
            }
                // Case 2: Item already exists
            else if (sbucket->key == item) {
                // If it's the first time encountering in this window, increase persistence (count)
                if (sbucket->status == 0) {
                    sbucket->count += 1;
                    sbucket->status = 1;
                }
                // Increase arrival strength (hotcount) every time it's encountered
                sbucket->hotcount +=1;
                return;
            }

            // Record the bucket with the minimum count among conflicting buckets
            if (sbucket->count < min_val) {
                min_val = sbucket->count;
                loc = index;
            }
        }

        // If all hash positions are conflicting, try to evict
        if (loc >= 0) {
            SBucket* sbucket_to_evict = &counts[loc];

            // If the eviction candidate has appeared in the current window, protect it and discard the new item
            if (sbucket_to_evict->status == 1) return;

            // Probabilistic eviction logic
            if (sbucket_to_evict->count < M_threshold) {
                // Use a higher eviction rate for cold items
                if ((rand() % (sbucket_to_evict->count + 1)) == 0) { // Probability is 1 / (count + 1)
                    sbucket_to_evict->count -= 1;
                }
            }
            else {
                // Use a lower eviction rate for hot items and protect them with hotcount
                if ((rand() % (sbucket_to_evict->hotcount * sbucket_to_evict->count + 1)) == 0) { // Probability is 1 / (count * hotcount + 1)
                    sbucket_to_evict->count -= 1;
                }
            }

            // If count is reduced to 0, eviction is successful, and the new item is placed
            if (sbucket_to_evict->count <= 0) {
                sbucket_to_evict->key = item;
                sbucket_to_evict->count = 1;
                sbucket_to_evict->hotcount = 1;
                sbucket_to_evict->status = 1;
            }
        }
    }

    COUNT_TYPE Query(const DATA_TYPE item) override {
        // For a reversible sketch, the query logic is to find the key and return its count
        for (int i = 0; i < depth; i++) {
            unsigned long bucket_idx = this->hash(item, i) % width;
            int index = i * width + bucket_idx;
            if (counts[index].key == item) {
                return counts[index].count; // Found a matching key, return the count directly
            }
        }
        return 0; // Traversed all hash positions and didn't find it, means the item doesn't exist, return 0
    }

    void NewWindow(const COUNT_TYPE window) override {
        QueryHotness(); // First, update hotcount based on the state of the previous window
        // Then, reset all status to 0 to prepare for the new window
        for (int i = 0; i < depth * width; i++) {
            counts[i].status = 0;
        }
    }

    void QueryHotness() {
        for (int i = 0; i < depth * width; i++) {
            if(counts[i].key == 0) continue; // Skip empty buckets

            if (counts[i].status == 0) { // Did not appear in the previous window
                // hotcount decays, but not below 0
                if (counts[i].hotcount > 0) {
                    counts[i].hotcount -= 1;
                }
            }
            else { // Appeared in the previous window
                counts[i].hotcount += 1;
            }
        }
    }

    std::string getName() override {
        return "TS";
    }

    void reset() override {
        sum = 0;

        for (int i = 0; i < depth * width; i++) {
            counts[i].count = 0;
            counts[i].hotcount = 0;
            counts[i].key = 0;
            counts[i].status = 0;
        }
    }
};

#endif //TIGHTSKETCH_H