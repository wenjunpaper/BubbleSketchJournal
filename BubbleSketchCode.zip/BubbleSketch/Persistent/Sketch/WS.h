#ifndef BENCH_WS_H
#define BENCH_WS_H

#include "Abstract.h"
#include "hash.h"
#include <vector>
#include <algorithm>
#include <iostream>
#include <stdexcept>
#include <cstring>


class BloomFilter {
public:
    BloomFilter(uint64_t memory_bytes, uint32_t num_hashes = 3)
            : num_hashes(num_hashes), size(memory_bytes * 8) {
        if (size == 0) {
            throw std::invalid_argument("BloomFilter memory cannot be zero.");
        }
        bits.resize(size, false);
        for (uint32_t i = 0; i < num_hashes; ++i) {
            seeds.push_back(Hash::generateRandomNumber());
        }
    }

    void Insert(const void* data, size_t len) {
        for (uint32_t i = 0; i < num_hashes; ++i) {
            bits[Hash::BOBHash32((const uint8_t*)data, len, seeds[i]) % size] = true;
        }
    }

    bool Query(const void* data, size_t len) const {
        for (uint32_t i = 0; i < num_hashes; ++i) {
            if (!bits[Hash::BOBHash32((const uint8_t*)data, len, seeds[i]) % size]) {
                return false;
            }
        }
        return true;
    }

    void Clear() {
        std::fill(bits.begin(), bits.end(), false);
    }

private:
    uint32_t num_hashes;
    uint64_t size;
    std::vector<bool> bits;
    std::vector<uint32_t> seeds;
};

template<typename DATA_TYPE, typename COUNT_TYPE, uint32_t d>
class WS : public Abstract<DATA_TYPE, COUNT_TYPE> {
public:
    struct Cell {
        DATA_TYPE id;
        COUNT_TYPE freq;
        bool flag;
    };

    struct Bucket {
        int64_t count;
        Cell heavy[d];

        Bucket() : count(0) {
            memset(heavy, 0, sizeof(heavy));
        }
    };

    WS(uint64_t memory_kb) {
        if (memory_kb <= 0) throw std::invalid_argument("Memory for WS must be positive.");
        uint64_t total_bytes = memory_kb * 1024;
        uint64_t bf_bytes = total_bytes * 0.25;
        uint64_t ws_bytes = total_bytes * 0.75;


        bloom_filter = new BloomFilter(bf_bytes);

        size_t bucket_size = sizeof(Bucket);
        this->l = ws_bytes / bucket_size;
        if (this->l == 0) throw std::runtime_error("Memory is too small for even one bucket in WS.");

        buckets = new Bucket[this->l];
        seed_h = Hash::generateRandomNumber();
        seed_s = Hash::generateRandomNumber();
    }

    ~WS() {
        delete bloom_filter;
        delete[] buckets;
    }

    std::string getName() override { return "WS"; }

    void Insert(const DATA_TYPE item, const COUNT_TYPE window) override {
        if (bloom_filter->Query(&item, sizeof(DATA_TYPE))) return;
        bloom_filter->Insert(&item, sizeof(DATA_TYPE));
        _Insert(item);
    }

    COUNT_TYPE Query(const DATA_TYPE item) override {
        uint32_t bucket_idx = h(item);
        Bucket& bucket = buckets[bucket_idx];
        for (uint32_t i = 0; i < d; ++i) {
            if (bucket.heavy[i].id == item) {
                if (bucket.heavy[i].flag) return bucket.heavy[i].freq;
                else break;
            }
        }
        return (COUNT_TYPE)std::max((int64_t)0, bucket.count * s(item));
    }

    void NewWindow(const COUNT_TYPE window) override { bloom_filter->Clear(); }

    void reset() override {
        bloom_filter->Clear();
        for(uint32_t i = 0; i < l; ++i) buckets[i] = Bucket();
        seed_h = Hash::generateRandomNumber();
        seed_s = Hash::generateRandomNumber();
    }

private:
    void _Insert(const DATA_TYPE item) {
        uint32_t bucket_idx = h(item);
        Bucket& bucket = buckets[bucket_idx];

        for (uint32_t i = 0; i < d; ++i) {
            if (bucket.heavy[i].id == item) {
                bucket.heavy[i].freq++;
                return;
            }
        }

        for (uint32_t i = 0; i < d; ++i) {
            if (bucket.heavy[i].id == 0) {
                bucket.heavy[i].id = item;
                bucket.heavy[i].freq = 1;
                bucket.heavy[i].flag = true;
                return;
            }
        }

        bucket.count += s(item);
        COUNT_TYPE f_hat = (COUNT_TYPE)std::max((int64_t)0, bucket.count * s(item));

        uint32_t min_pos = 0;
        for (uint32_t i = 1; i < d; ++i) {
            if (bucket.heavy[i].freq < bucket.heavy[min_pos].freq) min_pos = i;
        }

        if (f_hat > bucket.heavy[min_pos].freq) {
            Cell evicted_item = bucket.heavy[min_pos];
            bucket.heavy[min_pos] = {item, f_hat, false};
            if (evicted_item.flag) {
                bucket.count += (int64_t)evicted_item.freq * s(evicted_item.id);
            }
        }
    }

    inline uint32_t h(const DATA_TYPE item) const { return Hash::BOBHash32((const uint8_t*)&item, sizeof(DATA_TYPE), seed_h) % l; }
    inline int s(const DATA_TYPE item) const { return (Hash::BOBHash32((const uint8_t*)&item, sizeof(DATA_TYPE), seed_s) % 2) * 2 - 1; }

    uint32_t l;
    Bucket* buckets;
    BloomFilter* bloom_filter;
    uint32_t seed_h, seed_s;
};

#endif //BENCH_WS_H