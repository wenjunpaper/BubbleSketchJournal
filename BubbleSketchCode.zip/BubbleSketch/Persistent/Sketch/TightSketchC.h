#ifndef TIGHTSKETCH_H
#define TIGHTSKETCH_H

#include "Abstract.h"
#include <vector>
#include <cstring>
#include <limits> // 包含头文件以使用 std::numeric_limits

template<typename DATA_TYPE, typename COUNT_TYPE>
class TightSketch : public Abstract<DATA_TYPE, COUNT_TYPE> {
private:
    struct SBucket {
        COUNT_TYPE count;
        COUNT_TYPE hotcount;
        DATA_TYPE key;
        uint8_t status;

        SBucket() : count(0), hotcount(0), key(0), status(0) {}
    };

    int depth;
    int width;
    COUNT_TYPE M_threshold;
    COUNT_TYPE sum;
    SBucket* counts;

public:
    TightSketch(int _depth, int _width, COUNT_TYPE _M_threshold = 10)
            : depth(_depth), width(_width), M_threshold(_M_threshold), sum(0) {

        counts = new SBucket[depth * width]();
    }

    ~TightSketch() {
        delete[] counts;
    }

    void Insert(const DATA_TYPE item, const COUNT_TYPE window) override {
        sum += 1;
        int loc = -1;
        COUNT_TYPE min_val = std::numeric_limits<COUNT_TYPE>::max();

        for (int i = 0; i < depth; i++) {
            unsigned long bucket_idx = this->hash(item, i) % width;
            int index = i * width + bucket_idx;
            SBucket* sbucket = &counts[index];

            // 情况1: 桶为空，直接插入
            if (sbucket->key == 0) {
                sbucket->key = item;
                sbucket->count = 1;
                sbucket->hotcount = 1;
                sbucket->status = 1;
                return;
            }
                // 情况2: 项目已存在
            else if (sbucket->key == item) {
                // 如果是本窗口第一次遇到，增加持久性 (count)
                if (sbucket->status == 0) {
                    sbucket->count += 1;
                    sbucket->status = 1;
                }
                // 每次遇到都增加到达强度 (hotcount)
                sbucket->hotcount +=1;
                return;
            }

            // 记录冲突的桶中 count 最小的那个
            if (sbucket->count < min_val) {
                min_val = sbucket->count;
                loc = index;
            }
        }

        // 如果所有哈希位置都冲突，则尝试驱逐
        if (loc >= 0) {
            SBucket* sbucket_to_evict = &counts[loc];

            // 如果候选驱逐项在当前窗口已出现，则保护它，直接丢弃新项
            if (sbucket_to_evict->status == 1) return;

            // 概率驱逐逻辑
            if (sbucket_to_evict->count < M_threshold) {
                // 对冷项目使用较高的驱逐率
                if ((rand() % (sbucket_to_evict->count + 1)) == 0) { // 概率为 1 / (count + 1)
                    sbucket_to_evict->count -= 1;
                }
            }
            else {
                // 对热项目使用较低的驱逐率，并用 hotcount 加以保护
                if ((rand() % (sbucket_to_evict->hotcount * sbucket_to_evict->count + 1)) == 0) { // 概率为 1 / (count * hotcount + 1)
                    sbucket_to_evict->count -= 1;
                }
            }

            // 如果 count 减到 0，则驱逐成功，新项入驻
            if (sbucket_to_evict->count <= 0) {
                sbucket_to_evict->key = item;
                sbucket_to_evict->count = 1;
                sbucket_to_evict->hotcount = 1;
                sbucket_to_evict->status = 1;
            }
        }
    }

    COUNT_TYPE Query(const DATA_TYPE item) override {
        // 对于可逆 Sketch，查询逻辑是找到 key 并返回其 count
        for (int i = 0; i < depth; i++) {
            unsigned long bucket_idx = this->hash(item, i) % width;
            int index = i * width + bucket_idx;
            if (counts[index].key == item) {
                return counts[index].count; // 找到匹配的 key，直接返回 count
            }
        }
        return 0; // 遍历所有哈希位置都未找到，说明项目不存在，返回 0
    }

    void NewWindow(const COUNT_TYPE window) override {
        QueryHotness(); // 先根据上一窗口的状态更新 hotcount
        // 再将所有 status 重置为0，为新窗口做准备
        for (int i = 0; i < depth * width; i++) {
            counts[i].status = 0;
        }
    }

    void QueryHotness() {
        for (int i = 0; i < depth * width; i++) {
            if(counts[i].key == 0) continue; // 跳过空桶

            if (counts[i].status == 0) { // 上一窗口未出现
                // hotcount 衰减，但不低于0
                if (counts[i].hotcount > 0) {
                    counts[i].hotcount -= 1;
                }
            }
            else { // 上一窗口已出现
                counts[i].hotcount += 1;
            }
        }
    }

    std::string getName() override {
        return "TS";
    }

    void reset() override {
        sum = 0;

        for (int i = 0; i < depth * width; i++) {
            counts[i].count = 0;
            counts[i].hotcount = 0;
            counts[i].key = 0;
            counts[i].status = 0;
        }
    }
};

#endif //TIGHTSKETCH_H