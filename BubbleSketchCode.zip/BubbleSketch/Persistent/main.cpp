#include "benchmark.h"
#include <ctime>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int M = 4; //KB
    int W = 300;

    int c;
    char dataset[320]={'\0'};
    while((c = getopt(argc, argv, "d:m:w:")) != -1) {
        switch(c) {
            case 'd':
                strcpy(dataset, optarg);
                break;
            case 'm':
                M = atoi(optarg);
                break;
            case 'w':
                W = atoi(optarg);
                break;
        }
    }

    BenchMark<uint64_t , int64_t > benchMark(dataset, W,  M);

    benchMark.begin();

    return 0;
}
